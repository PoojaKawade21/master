package com.digitalbooks.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.digitalbooks.entities.Book;
import com.digitalbooks.exception.BookServiceException;
import com.digitalbooks.repositories.BookServiceRepository;

@Service
public class BookService {

	@Autowired
	private BookServiceRepository repo;

	public List<Book> getAllBooks() {
		return repo.findAll();
	}

	public List<Book> getBooks(String category) {
		return null;// repo.findBy(category,null);
	}

	public Book getBookById(int bookid) throws BookServiceException {
		Optional<Book> optional = repo.findById(bookid);

		if (optional.isEmpty()) {
			throw new BookServiceException("Movie not found with id: " + bookid);
		} else {
			return optional.get();
		}
	}

	public Book saveBook(Book book) {
		return repo.save(book);
	}

	public Book updateBook(Book book) throws BookServiceException {
		if (repo.existsById(book.getId())) {
			return repo.save(book);
		} else {
			throw new BookServiceException("Book not updated with Id: " + book.getId());
		}

	}

	/*
	 * public Book delete(int bookId) throws BookServiceException { Optional<Book>
	 * optional = repo.findById(bookId);
	 * 
	 * if (optional.isEmpty()) { throw new
	 * BookServiceException("Book not found with id: " + bookId); } else {
	 * repo.deleteById(bookId); return optional.get(); } }
	 */

}
