package com.digitalbook.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.digitalbook.entities.Reader;
import com.digitalbook.repositories.ReaderServiceRepository;



@Service
public class ReaderService {

   
    @Autowired
    private ReaderServiceRepository repo;
    
    public List<Reader> getAllReaders(){
        return repo.findAll();
    }
    
    

    
}
