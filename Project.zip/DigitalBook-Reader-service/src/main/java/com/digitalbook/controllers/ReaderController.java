package com.digitalbook.controllers;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.digitalbook.clients.BookServiceClient;
import com.digitalbook.models.Book;

@RestController
@RequestMapping("/api/v1/digitalbooks/books")
public class ReaderController {

	@Autowired
	private BookServiceClient bookServiceClient;

	 
	 @GetMapping("/searchbooks")
		public List<Book> getAllBooks() {
			return bookServiceClient.getAllBooks();
		}
	 
	 @GetMapping("/search")
		public List<Book> getBooks(@RequestParam  String category) {
			return bookServiceClient.getBooks(category);
		}
	 

		/*
		 * @GetMapping("/getBooks") public List<Show> getBooksFromBookService() {
		 * 
		 * return bookServiceClient.getBooks();
		 * 
		 * }
		 */

}
